import logging

logging.getLogger('azure.storage.common.storageclient').setLevel(logging.WARNING)
