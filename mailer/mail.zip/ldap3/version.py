# THIS FILE IS AUTO-GENERATED. PLEASE DO NOT MODIFY# version file for ldap3
# generated on 2019-09-06 06:08:03.928047
# on system uname_result(system='Windows', node='ELITE10GC', release='10', version='10.0.18362', machine='AMD64', processor='Intel64 Family 6 Model 58 Stepping 9, GenuineIntel')
# with Python 3.7.4 - ('tags/v3.7.4:e09359112e', 'Jul  8 2019 20:34:20') - MSC v.1916 64 bit (AMD64)
#
__version__ = '2.6.1'
__author__ = 'Giovanni Cannata'
__email__ = 'cannatag@gmail.com'
__url__ = 'https://github.com/cannatag/ldap3'
__description__ = 'A strictly RFC 4510 conforming LDAP V3 pure Python client library'
__status__ = '5 - Production/Stable'
__license__ = 'LGPL v3'
