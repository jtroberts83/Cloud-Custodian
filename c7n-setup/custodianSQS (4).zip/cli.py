import argparse
from c7n_worker import C7nWorker

def setup_parser():
  parser = argparse.ArgumentParser(description="C7n Worker")
  parser.add_argument('-q', '--queue-url', required=True, help='SQS Queue to poll for jobs')
  parser.add_argument('-b', '--bucket-name', required=True, help='S3 Bucket to save logs')
  parser.add_argument('--custodian',
                      help='Path to the custodian executable',
                      default="custodian")
  parser.add_argument('--global-configs',
                      help='Path to configs for global resources',
                      nargs="+",
                      default=["globalpolicies.yaml"])
  parser.add_argument('--regional-configs',
                      help='Path to configs for regional resources',
                      nargs="+",
                      default=["regionalpolicies.yaml"])
  parser.add_argument('--max-messages',
                      help='Maximum number of messages to receive in one poll',
                      type=int,
                      default=1)
  return parser

def main():
  parser = setup_parser()
  options = parser.parse_args()
  C7nWorker(**vars(options)).run()

if __name__ == '__main__':
  main()
