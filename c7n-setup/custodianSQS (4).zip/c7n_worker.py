from __future__ import print_function
from datetime import datetime
import boto3
import json
import re
import subprocess
import time
import traceback

class C7nWorker:
  def __init__(self, queue_url, bucket_name, custodian="custodian",
               global_configs=["globalpolicies.yaml"],
               regional_configs=["regionalpolicies.yaml"],
               max_messages=1):
    self.queue_url = queue_url
    self.bucket_name = bucket_name
    self.custodian = custodian
    self.global_configs = global_configs
    self.regional_configs = regional_configs
    self.max_number_of_messages = max_messages

    self.wait_time_seconds = 20

  # Create the SQS client
  def client(self):
    return boto3.client('sqs')

  # Find the account in in a ARN
  @staticmethod
  def account_id_from_arn(arn):
    return re.match(r'^arn:(?:[^:]*:){3}(\d+):.*$', arn).group(1)

  # Construct the S3 URL for storing logs
  def s3_url(self, account_id, region_name, timestamp):
    if region_name == None:
      region_name = "global"

    time = timestamp.timetuple()

    return "/".join([
      "s3:/",
      self.bucket_name,
      "AWSLogs",
      account_id,
      "c7n",
      region_name,
      "{:04d}".format(time.tm_year),
      "{:02d}".format(time.tm_mon),
      "{:02d}".format(time.tm_mday),
      "{account_id}_c7n_{region_name}_{timestamp}".format(
        account_id=account_id,
        region_name=region_name,
        timestamp=timestamp.isoformat()
      )
    ])

  # Execute cloud custodian (c7n) for the combination of the role_arn and
  # region name. When region name is None, use this to scan global resources
  # like IAM resources
  def execute_c7n(self, role_arn, region_name):
    now = datetime.utcnow()
    account_id = C7nWorker.account_id_from_arn(role_arn)

    print("Running c7n: {account_id} ({region_name})".format(
      account_id=account_id,
      region_name=region_name or "global"
    ))

    command = [
      self.custodian,
      "run",
      "--metrics-enabled",
      "--output-dir", self.s3_url(account_id, region_name, now),
      "--assume", role_arn
    ]

    if region_name == None:
      # Use AWS_DEFAULT_REGION instead of passing a --region here
      command += self.global_configs
    else:
      command += [
        "--region", region_name,
      ] + self.regional_configs

    # Actually run c7n!
    exit_code = subprocess.call(command)

    print("Done")

    # If the exit code of c7n was non-zero, raise an exception so that the
    # message will not be removed from the SQS queue, and the job will be
    # retried after the visibility timeout times out
    if exit_code != 0:
      raise Exception(
        "C7n exited with a non-zero exit code ({exit_code}): {command}".format(
          exit_code=exit_code,
          command=" ".join(command)
        )
      )

  # Delete a message from the SQS queue, so that it will not be delivered
  # yet another time
  def delete_message(self, message):
    self.client().delete_message(
      QueueUrl=self.queue_url,
      ReceiptHandle=message["ReceiptHandle"]
    )

  # Poll SQS once and handle all received messages
  def poll(self):
    response = self.client().receive_message(
      QueueUrl=self.queue_url,
      WaitTimeSeconds=self.wait_time_seconds,
      MaxNumberOfMessages=self.max_number_of_messages
    )
    # Run c7n for each message received from the queue, if any...
    if "Messages" in response:
      for message in response["Messages"]:
        data = json.loads(message["Body"])
        try:
          # Execute a run of c7n for this combination of role_arn and
          # region_name
          self.execute_c7n(**data)
          # If no exception was raised during execution of c7n, assume the
          # run was successful and thus remove the message from the queue
          self.delete_message(message)
        except Exception as e:
          print("Error handling message: {}".format(e))
          print(traceback.format_exc())
          pass

  # Start a loop polling SQS
  def run(self):
    print("Cloud Custodian Worker")
    print("======================")
    print("SQS Queue: {}".format(self.queue_url))
    print("S3 Bucket: {}".format(self.bucket_name))
    print("Custodian: {}".format(self.custodian))
    print("   Global: {}".format(self.global_configs))
    print(" Regional: {}".format(self.regional_configs))
    print(" Messages: {}".format(self.max_number_of_messages))
    print("")
    print("Starting polling the queue now.")
    while True:
      # Poll SQS for messages and execute c7n for each message
      self.poll()
      # Sleep, to prevent us from hitting the SQS API too often
      time.sleep(1)
